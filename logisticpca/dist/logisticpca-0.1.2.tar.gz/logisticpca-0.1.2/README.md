# LogisticPCA

A Python implementation of Logistic PCA for dimensionality reduction of binary data.
Supports Logistic PCA and Probabilistic PCA.

## Installation
```bash
pip install logisticpca

